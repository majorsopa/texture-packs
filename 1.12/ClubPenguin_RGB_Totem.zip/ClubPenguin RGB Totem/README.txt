This pack was created by Papa Quill -
Join the discord for more texture packs and a bunch of giveaways!
https://discord.gg/resxWhbYyn