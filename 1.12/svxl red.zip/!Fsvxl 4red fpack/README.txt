original pack (1.8.9)
https://www.mediafire.com/file/k72phklb27g12hd/%25C2%25A74Stimpy_%25C2%25A78Private_%25C2%25A77Revamp_%25C2%25A78%255B%25C2%25A7f128x%25C2%25A78%255D.zip/file
https://www.youtube.com/watch?v=OYEsMDGnP-8