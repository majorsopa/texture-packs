the 1.12.2 port fucked up somehow and im too lazy to fix.
dm me on discord if you want me to fix it (looser#7387)
enjoy?