This pack was originally created by 3vt
Optimized by Papa Quill.

Removed useless files taking up extra space and removed files that are unchanged from defualt MC for more compatibility. 


I adjust some shit. Put in some textures that I like :)

-Lempity