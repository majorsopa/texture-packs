All original pack credits go to Milo
Optimizations made by Papa Quill.
Removed some extra files that were not changed by the pack,
decreasing the file size and making it more compatible with other packs
that may change those textures.