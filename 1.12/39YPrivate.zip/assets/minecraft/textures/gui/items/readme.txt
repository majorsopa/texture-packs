fuck your "private" popbob totem. 
This took me 15 minutes in photoshop and is IDENTICAL to the "private one".

Photoshop file: https://cdn.discordapp.com/attachments/637618882361819147/637818860346671104/Popbob_totem.psd

Fums is best